﻿class RegException : Exception {
    public RegException(string message) : base(message) {
    
    }
}
