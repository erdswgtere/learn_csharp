﻿
interface IAllRegistrarion {
    static void AllInfo() {

    }
    static void Selection() {

    }
}
