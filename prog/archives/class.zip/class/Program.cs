﻿internal class Program
{
    private static void Main(string[] args)
    {
        Calculate calculate = new Calculate(2 , 3);
        Console.WriteLine("Сумма квадратов = {0}",calculate.Addition());
        calculate.Inf();
    }
}

public class Calculate
{
   private readonly int a;
   private readonly int b;

   public Calculate(int number1, int number2)
   {
      a = number1;
      b = number2;
   }
   public void Inf()
   {
       Console.WriteLine("Поле1 = {0}\nПоле2 = {1} ",a, b);
   }
   public double Addition() 
   {
       return Math.Pow(a, 2) +  Math.Pow(b, 2);
   }

   // Remaining implementation of Person class.
}