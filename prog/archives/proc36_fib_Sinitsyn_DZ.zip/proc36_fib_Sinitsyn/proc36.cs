namespace fib{
    public static class Fibre{
        public static int Fib(ref int k){
            int fibfirst=1, fibsecond = 1;
            int fib = 0;
            Console.Write($"{fibfirst} ");
            for(int i = 0; i < k - 1 ; i++){
                fib = fibsecond + fibfirst;
                fibsecond = fibfirst;
                fibfirst = fib;
                Console.Write($"{fib} ");
            }
            Console.WriteLine();
            Console.Write($"N-ый член последовательности: ");
            return fib;
        }
    }
}